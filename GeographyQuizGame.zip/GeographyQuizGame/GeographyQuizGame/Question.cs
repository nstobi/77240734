﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeographyQuizGame
{
    public enum QuestionType
    {
        MultipleChoice,
        OpenEnded,
        TrueFalse
    }

    // Question class to store question details
    public class Question
    {
        public string Text { get; }
        public List<string> Answers { get; }
        public int CorrectAnswerIndex { get; }
        public QuestionType Type { get; }

        public Question(string text, List<string> answers, int correctAnswerIndex, QuestionType type)
        {
            Text = text;
            Answers = answers;
            CorrectAnswerIndex = correctAnswerIndex;
            Type = type;
        }
    }
}
