﻿namespace GeographyQuizGame
{
    partial class PlayGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMultipleChoice = new System.Windows.Forms.Panel();
            this.rbtnAnswer4 = new System.Windows.Forms.RadioButton();
            this.rbtnAnswer3 = new System.Windows.Forms.RadioButton();
            this.rbtnAnswer2 = new System.Windows.Forms.RadioButton();
            this.rbtnAnswer1 = new System.Windows.Forms.RadioButton();
            this.pnlOpenEnded = new System.Windows.Forms.Panel();
            this.txtOpenEndedResponse = new System.Windows.Forms.TextBox();
            this.pnlTrueFalse = new System.Windows.Forms.Panel();
            this.rbtnFalse = new System.Windows.Forms.RadioButton();
            this.rbtnTrue = new System.Windows.Forms.RadioButton();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.pnlMultipleChoice.SuspendLayout();
            this.pnlOpenEnded.SuspendLayout();
            this.pnlTrueFalse.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMultipleChoice
            // 
            this.pnlMultipleChoice.Controls.Add(this.rbtnAnswer4);
            this.pnlMultipleChoice.Controls.Add(this.rbtnAnswer3);
            this.pnlMultipleChoice.Controls.Add(this.rbtnAnswer2);
            this.pnlMultipleChoice.Controls.Add(this.rbtnAnswer1);
            this.pnlMultipleChoice.Location = new System.Drawing.Point(12, 58);
            this.pnlMultipleChoice.Name = "pnlMultipleChoice";
            this.pnlMultipleChoice.Size = new System.Drawing.Size(217, 235);
            this.pnlMultipleChoice.TabIndex = 0;
            // 
            // rbtnAnswer4
            // 
            this.rbtnAnswer4.AutoSize = true;
            this.rbtnAnswer4.Location = new System.Drawing.Point(3, 72);
            this.rbtnAnswer4.Name = "rbtnAnswer4";
            this.rbtnAnswer4.Size = new System.Drawing.Size(69, 17);
            this.rbtnAnswer4.TabIndex = 3;
            this.rbtnAnswer4.TabStop = true;
            this.rbtnAnswer4.Text = "Answer 4";
            this.rbtnAnswer4.UseVisualStyleBackColor = true;
            // 
            // rbtnAnswer3
            // 
            this.rbtnAnswer3.AutoSize = true;
            this.rbtnAnswer3.Location = new System.Drawing.Point(3, 49);
            this.rbtnAnswer3.Name = "rbtnAnswer3";
            this.rbtnAnswer3.Size = new System.Drawing.Size(69, 17);
            this.rbtnAnswer3.TabIndex = 2;
            this.rbtnAnswer3.TabStop = true;
            this.rbtnAnswer3.Text = "Answer 3";
            this.rbtnAnswer3.UseVisualStyleBackColor = true;
            // 
            // rbtnAnswer2
            // 
            this.rbtnAnswer2.AutoSize = true;
            this.rbtnAnswer2.Location = new System.Drawing.Point(3, 26);
            this.rbtnAnswer2.Name = "rbtnAnswer2";
            this.rbtnAnswer2.Size = new System.Drawing.Size(69, 17);
            this.rbtnAnswer2.TabIndex = 1;
            this.rbtnAnswer2.TabStop = true;
            this.rbtnAnswer2.Text = "Answer 2";
            this.rbtnAnswer2.UseVisualStyleBackColor = true;
            // 
            // rbtnAnswer1
            // 
            this.rbtnAnswer1.AutoSize = true;
            this.rbtnAnswer1.Location = new System.Drawing.Point(3, 3);
            this.rbtnAnswer1.Name = "rbtnAnswer1";
            this.rbtnAnswer1.Size = new System.Drawing.Size(69, 17);
            this.rbtnAnswer1.TabIndex = 0;
            this.rbtnAnswer1.TabStop = true;
            this.rbtnAnswer1.Text = "Answer 1";
            this.rbtnAnswer1.UseVisualStyleBackColor = true;
            // 
            // pnlOpenEnded
            // 
            this.pnlOpenEnded.Controls.Add(this.txtOpenEndedResponse);
            this.pnlOpenEnded.Location = new System.Drawing.Point(281, 58);
            this.pnlOpenEnded.Name = "pnlOpenEnded";
            this.pnlOpenEnded.Size = new System.Drawing.Size(217, 235);
            this.pnlOpenEnded.TabIndex = 1;
            // 
            // txtOpenEndedResponse
            // 
            this.txtOpenEndedResponse.Location = new System.Drawing.Point(3, 3);
            this.txtOpenEndedResponse.Multiline = true;
            this.txtOpenEndedResponse.Name = "txtOpenEndedResponse";
            this.txtOpenEndedResponse.Size = new System.Drawing.Size(211, 229);
            this.txtOpenEndedResponse.TabIndex = 0;
            // 
            // pnlTrueFalse
            // 
            this.pnlTrueFalse.Controls.Add(this.rbtnFalse);
            this.pnlTrueFalse.Controls.Add(this.rbtnTrue);
            this.pnlTrueFalse.Location = new System.Drawing.Point(571, 58);
            this.pnlTrueFalse.Name = "pnlTrueFalse";
            this.pnlTrueFalse.Size = new System.Drawing.Size(217, 235);
            this.pnlTrueFalse.TabIndex = 1;
            // 
            // rbtnFalse
            // 
            this.rbtnFalse.AutoSize = true;
            this.rbtnFalse.Location = new System.Drawing.Point(3, 27);
            this.rbtnFalse.Name = "rbtnFalse";
            this.rbtnFalse.Size = new System.Drawing.Size(50, 17);
            this.rbtnFalse.TabIndex = 1;
            this.rbtnFalse.TabStop = true;
            this.rbtnFalse.Text = "False";
            this.rbtnFalse.UseVisualStyleBackColor = true;
            // 
            // rbtnTrue
            // 
            this.rbtnTrue.AutoSize = true;
            this.rbtnTrue.Location = new System.Drawing.Point(3, 4);
            this.rbtnTrue.Name = "rbtnTrue";
            this.rbtnTrue.Size = new System.Drawing.Size(47, 17);
            this.rbtnTrue.TabIndex = 0;
            this.rbtnTrue.TabStop = true;
            this.rbtnTrue.Text = "True";
            this.rbtnTrue.UseVisualStyleBackColor = true;
            // 
            // lblQuestion
            // 
            this.lblQuestion.AutoSize = true;
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.Location = new System.Drawing.Point(311, 9);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(137, 31);
            this.lblQuestion.TabIndex = 2;
            this.lblQuestion.Text = "Questions";
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(680, 400);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(108, 38);
            this.btnNext.TabIndex = 4;
            this.btnNext.Text = "Next Question";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // PlayGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.lblQuestion);
            this.Controls.Add(this.pnlTrueFalse);
            this.Controls.Add(this.pnlOpenEnded);
            this.Controls.Add(this.pnlMultipleChoice);
            this.Name = "PlayGame";
            this.Text = "PlayGame";
            this.pnlMultipleChoice.ResumeLayout(false);
            this.pnlMultipleChoice.PerformLayout();
            this.pnlOpenEnded.ResumeLayout(false);
            this.pnlOpenEnded.PerformLayout();
            this.pnlTrueFalse.ResumeLayout(false);
            this.pnlTrueFalse.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlMultipleChoice;
        private System.Windows.Forms.Panel pnlOpenEnded;
        private System.Windows.Forms.Panel pnlTrueFalse;
        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.RadioButton rbtnAnswer4;
        private System.Windows.Forms.RadioButton rbtnAnswer3;
        private System.Windows.Forms.RadioButton rbtnAnswer2;
        private System.Windows.Forms.RadioButton rbtnAnswer1;
        private System.Windows.Forms.TextBox txtOpenEndedResponse;
        private System.Windows.Forms.RadioButton rbtnFalse;
        private System.Windows.Forms.RadioButton rbtnTrue;
        private System.Windows.Forms.Button btnNext;
    }
}