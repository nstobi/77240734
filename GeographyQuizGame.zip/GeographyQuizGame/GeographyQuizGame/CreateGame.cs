﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace GeographyQuizGame
{
    public partial class CreateGame : Form
    {
        // List to store questions
        private List<Question> questions = new List<Question>();

        public CreateGame()
        {
            InitializeComponent();
            InitializeCustomComponents();
        }

        private void InitializeCustomComponents()
        {
            // Populate the question type ComboBox
            cmbQuestionType.Items.AddRange(new[] { "Multiple Choice", "Open-Ended", "True/False" });
            cmbQuestionType.SelectedIndexChanged += cmbQuestionType_SelectedIndexChanged;

            // Initial visibility for dynamic fields
            SetVisibility(false, false, false);
        }

        private void cmbQuestionType_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Adjust visibility based on selected question type
            SetVisibility(false, false, false);

            switch (cmbQuestionType.SelectedIndex)
            {
                case 0: // Multiple Choice
                    SetVisibility(true, false, false);
                    break;
                case 1: // Open-Ended
                    txtOpenEndedAnswer.Visible = true;
                    break;
                case 2: // True/False
                    rbtnTrue.Visible = rbtnFalse.Visible = true;
                    break;
            }
        }

        private void btnAddQuestion_Click(object sender, EventArgs e)
        {
            string questionText = txtQuestion.Text;
            if (string.IsNullOrWhiteSpace(questionText))
            {
                MessageBox.Show("Question text cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            switch (cmbQuestionType.SelectedIndex)
            {
                case 0: // Multiple Choice
                    var answers = new List<string> { txtAnswer1.Text, txtAnswer2.Text, txtAnswer3.Text, txtAnswer4.Text };
                    int correctIndex = cmbCorrectAnswer.SelectedIndex;
                    if (correctIndex == -1 || answers.Any(string.IsNullOrWhiteSpace))
                    {
                        MessageBox.Show("Please complete all fields for multiple-choice questions.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    questions.Add(new Question(questionText, answers, correctIndex, QuestionType.MultipleChoice));
                    break;

                case 1: // Open-Ended
                    string openEndedAnswer = txtOpenEndedAnswer.Text;
                    if (string.IsNullOrWhiteSpace(openEndedAnswer))
                    {
                        MessageBox.Show("Answer cannot be empty for open-ended questions.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    questions.Add(new Question(questionText, new List<string> { openEndedAnswer }, 0, QuestionType.OpenEnded));
                    break;

                case 2: // True/False
                    int trueFalseAnswer = rbtnTrue.Checked ? 0 : (rbtnFalse.Checked ? 1 : -1);
                    if (trueFalseAnswer == -1)
                    {
                        MessageBox.Show("Please select True or False for the question.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    questions.Add(new Question(questionText, new List<string> { "True", "False" }, trueFalseAnswer, QuestionType.TrueFalse));
                    break;

                default:
                    MessageBox.Show("Please select a question type.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
            }

            // Clear inputs and update list
            ClearInputs();
            UpdateQuestionList();
        }

        private void ClearInputs()
        {
            txtQuestion.Clear();
            txtAnswer1.Clear();
            txtAnswer2.Clear();
            txtAnswer3.Clear();
            txtAnswer4.Clear();
            txtOpenEndedAnswer.Clear();
            rbtnTrue.Checked = rbtnFalse.Checked = false;
            cmbCorrectAnswer.SelectedIndex = -1;
            cmbQuestionType.SelectedIndex = -1;
        }

        private void UpdateQuestionList()
        {
            lstQuestions.Items.Clear();
            foreach (var question in questions)
            {
                lstQuestions.Items.Add(question.Text);
            }
        }

        private void SetVisibility(bool multipleChoice, bool openEnded, bool trueFalse)
        {
            // Multiple choice fields
            txtAnswer1.Visible = txtAnswer2.Visible = txtAnswer3.Visible = txtAnswer4.Visible = multipleChoice;
            cmbCorrectAnswer.Visible = multipleChoice;

            // Open-ended fields
            txtOpenEndedAnswer.Visible = openEnded;

            // True/False fields
            rbtnTrue.Visible = rbtnFalse.Visible = trueFalse;
        }

        private void btnDeleteQuestion_Click(object sender, EventArgs e)
        {
            if (lstQuestions.SelectedIndex >= 0)
            {
                questions.RemoveAt(lstQuestions.SelectedIndex);
                UpdateQuestionList();
            }
            else
            {
                MessageBox.Show("Please select a question to delete.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnEditQuestion_Click(object sender, EventArgs e)
        {
            if (lstQuestions.SelectedIndex >= 0)
            {
                // Retrieve the selected question
                var selectedQuestion = questions[lstQuestions.SelectedIndex];

                // Populate the fields with the selected question details
                txtQuestion.Text = selectedQuestion.Text;

                switch (selectedQuestion.Type)
                {
                    case QuestionType.MultipleChoice:
                        cmbQuestionType.SelectedIndex = 0;
                        txtAnswer1.Text = selectedQuestion.Answers[0];
                        txtAnswer2.Text = selectedQuestion.Answers[1];
                        txtAnswer3.Text = selectedQuestion.Answers[2];
                        txtAnswer4.Text = selectedQuestion.Answers[3];
                        cmbCorrectAnswer.SelectedIndex = selectedQuestion.CorrectAnswerIndex;
                        break;

                    case QuestionType.OpenEnded:
                        cmbQuestionType.SelectedIndex = 1;
                        txtOpenEndedAnswer.Text = selectedQuestion.Answers[0];
                        break;

                    case QuestionType.TrueFalse:
                        cmbQuestionType.SelectedIndex = 2;
                        rbtnTrue.Checked = selectedQuestion.CorrectAnswerIndex == 0;
                        rbtnFalse.Checked = selectedQuestion.CorrectAnswerIndex == 1;
                        break;
                }

                // Remove the selected question to avoid duplicates when re-adding
                questions.RemoveAt(lstQuestions.SelectedIndex);
                UpdateQuestionList();
            }
            else
            {
                MessageBox.Show("Please select a question to edit.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnPlayGame_Click(object sender, EventArgs e)
        {
            if (questions.Count == 0)
            {
                MessageBox.Show("No questions available to play. Please add questions first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Open PlayGame form and pass the questions list
            PlayGame playGameForm = new PlayGame(questions);
            playGameForm.ShowDialog();
        }
    }
}
