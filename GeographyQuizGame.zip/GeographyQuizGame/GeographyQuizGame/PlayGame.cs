﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;

namespace GeographyQuizGame
{
    public partial class PlayGame : Form
    {
        private List<Question> questions;
        private int currentQuestionIndex = 0;
        private int score = 0;

        public PlayGame(List<Question> questions)
        {
            InitializeComponent();
            this.questions = questions;
            ShowQuestion();
        }

        private void ShowQuestion()
        {
            if (currentQuestionIndex >= questions.Count)
            {
                EndGame();
                return;
            }

            // Hide all panels initially
            pnlMultipleChoice.Visible = false;
            pnlOpenEnded.Visible = false;
            pnlTrueFalse.Visible = false;

            Question currentQuestion = questions[currentQuestionIndex];
            lblQuestion.Text = currentQuestion.Text;

            switch (currentQuestion.Type)
            {
                case QuestionType.MultipleChoice:
                    pnlMultipleChoice.Visible = true;
                    rbtnAnswer1.Text = currentQuestion.Answers[0];
                    rbtnAnswer2.Text = currentQuestion.Answers[1];
                    rbtnAnswer3.Text = currentQuestion.Answers[2];
                    rbtnAnswer4.Text = currentQuestion.Answers[3];
                    rbtnAnswer1.Checked = rbtnAnswer2.Checked = rbtnAnswer3.Checked = rbtnAnswer4.Checked = false;
                    break;

                case QuestionType.OpenEnded:
                    pnlOpenEnded.Visible = true;
                    txtOpenEndedResponse.Clear();
                    break;

                case QuestionType.TrueFalse:
                    pnlTrueFalse.Visible = true;
                    rbtnTrue.Checked = rbtnFalse.Checked = false;
                    break;
            }
        }

        private void EvaluateCurrentAnswer()
        {
            Question currentQuestion = questions[currentQuestionIndex];

            switch (currentQuestion.Type)
            {
                case QuestionType.MultipleChoice:
                    if ((rbtnAnswer1.Checked && currentQuestion.CorrectAnswerIndex == 0) ||
                        (rbtnAnswer2.Checked && currentQuestion.CorrectAnswerIndex == 1) ||
                        (rbtnAnswer3.Checked && currentQuestion.CorrectAnswerIndex == 2) ||
                        (rbtnAnswer4.Checked && currentQuestion.CorrectAnswerIndex == 3))
                    {
                        score++;
                    }
                    break;

                case QuestionType.OpenEnded:
                    if (txtOpenEndedResponse.Text.Trim().Equals(currentQuestion.Answers[0], StringComparison.OrdinalIgnoreCase))
                    {
                        score++;
                    }
                    break;

                case QuestionType.TrueFalse:
                    if ((rbtnTrue.Checked && currentQuestion.CorrectAnswerIndex == 0) ||
                        (rbtnFalse.Checked && currentQuestion.CorrectAnswerIndex == 1))
                    {
                        score++;
                    }
                    break;
            }
        }

        private void EndGame()
        {
            MessageBox.Show($"Game Over!\nYour score: {score}/{questions.Count}", "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            EvaluateCurrentAnswer();
            currentQuestionIndex++;
            ShowQuestion();
        }
    }
}
